<?php
return array (
  'app_version' => 'v6.0.12',
  'full_app_version' => 'v6.0.12 - build 8824-g915186883',
  'build_version' => '8824',
  'prerelease_version' => '',
  'hash_version' => 'g915186883',
  'full_hash' => 'v6.0.12-64-g915186883',
  'branch' => 'master',
);