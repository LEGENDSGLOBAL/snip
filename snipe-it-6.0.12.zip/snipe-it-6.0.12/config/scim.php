<?php

return [
    "publish_routes" => false,
    "trace" => env("SCIM_TRACE",false)
];
